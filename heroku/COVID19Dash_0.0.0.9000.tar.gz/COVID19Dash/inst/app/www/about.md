
## About this app

This app was originally built by [Parker &
Leclerc](https://vac-lshtm.shinyapps.io/ncov_tracker/#) to visualize
COVID-19 cases and deaths. What’s presented here is a conversion of
parts of it to a modularized `{golem}` framework by [Basil
Okola](https://github.com/bokola).
